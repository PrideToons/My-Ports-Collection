## REDO! ported by Pridetoons
REDO is a dark Sci-Fi Metroidvania set in a Post Apocalyptic world. You play as the last human on earth fighting against entire hoards of robots.

[INSTRUCTIONS]
Just copy and paste the game files from your purchased copy of REDO to the gamedata folder.

Thank You redo99 for creating such an amazing game!

Also be on the look out for Sessions by redo99!

Check out his Itch.io page here!
https://redo99.itch.io/
