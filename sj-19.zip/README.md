## SJ-19 Learns to Love! ported by Pridetoons
SJ-19 Learns to Love! is a fun metroidvania game from the creative mind of Zertuk! 

[INSTRUCTIONS]

1)Download your purchased copy of "SJ-19 Learns to Love" from Steam or Itch.io.
2)Copy "sj-19-learns-to-love.pck" to "sj-19" folder.
3)Run ".sh" file.
4)ENJOY!!! :)

Thank you Zertuk for this amazing Indie Game!
