## Treasure Hunter Man 2 ported by Pridetoons

Treasure Hunter Man 2 is an exploratory platformer or metroidvania. You play as Dorothy as she grows stronger and gains new abilities. Join her as she explores and uncovers the mysteries of a deserted and seemingly cursed island.

{Story}
Teenage sons are already a headache, but if they run away to hunt for treasure, that's where many a mum might be a bit out of her element. Not Dorothy, however! With a magical compass in hand, Dorothy tracks down her son's whereabouts to a deserted island. There'll be no more missed dinners or cursed treasures in THIS household! In the end, there's only one TRUE treasure for Dorothy.

[INSTRUCTIONS]
Just copy and paste the game files from your purchased copy of REDO to the gamedata folder.

Thank You origamihero for creating such an amazing game!

Check out his Itch.io page here!
https://origamihero.itch.io/
