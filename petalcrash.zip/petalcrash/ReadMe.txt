[INSTRUCTIONS]

1)Download Linux Version of Petal Crash.
2)Copy all game files minus the bin64 folder and run.sh file from your purchased copy of Petal Crush to the gamedata folder.
3)Run Petal Crash Shell Script (.sh file).
4)ENJOY!!! :)
