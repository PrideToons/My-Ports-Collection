# Petal-Crash-Port
Here's a Port of Petal Crash for ARM Handhelds running Emulation Station. Please give feedback on this port and many others on the Portmaster Discord

[INSTRUCTIONS]

1)Download Linux Version of Petal Crash.
2)Copy all game files minus the bin64 folder and run.sh file from your purchased copy of Petal Crash.
3)Move ".sh" file to Ports folder.
4)ENJOY!!! :)

# A Special Thanks!!!

A special thanks to both 'Friend and Fairy' and 'GalaxyTrail' for developing and publishing this indie gem! 
